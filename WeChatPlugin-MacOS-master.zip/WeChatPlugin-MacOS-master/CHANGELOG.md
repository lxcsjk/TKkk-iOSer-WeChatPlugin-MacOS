# 更新日志 

### [v1.7.5 (2019-01-13)](https://github.com/TKkk-iOSer/WeChatPlugin-MacOS/releases/tag/v1.7.5)

- 适配 2.3.22
- 新增禁止微信检测更新开关
- 优化 XML解析(在此感谢 @wangliangliang2 提醒)

###[v1.7.3 (2018-10-23)](https://github.com/TKkk-iOSer/WeChatPlugin-MacOS/releases/tag/v1.7.3)

- 适配2.3.19
- 菜单栏新增 alfred 开关
- 更改更新弹窗逻辑
- 新增自带浏览器浏览开关

### [v1.7.1 (2018-07-24)](https://github.com/TKkk-iOSer/WeChatPlugin-MacOS/releases/tag/v1.7.1)

* 适配微信 Version. 2.3.17
* 新增 alfred 搜索最近聊天列表
* 新增 alfred 查看用户聊天记录

### [v1.7 (2018-05-12)](https://github.com/TKkk-iOSer/WeChatPlugin-MacOS/releases/tag/v1.7)

* 新增不同账户设置不同的自动回复&远程控制
* 自动回复新增总开关&指定联系人
* 远程控制新增控制小助手配置
* 新增一键已读
* 新增一键清除空回话
* 新增国际化(支持英、简、繁)
* 新增关于小助手
* 新增在线更新小助手
* 去除微信url转链处理(从此直接打开抖音链接🌝
* 修复无法免认证登录&多开等bug

### [v1.6.1 (2018-04-07)](https://github.com/TKkk-iOSer/WeChatPlugin-MacOS/releases/tag/v1.6.1)

* 自动回复新增延迟回复
* 调整置顶模式快捷键
* 修复bug & 优化代码
* 更新 README.md 文档 

### [v1.6 (2018-03-18)](https://github.com/TKkk-iOSer/WeChatPlugin-MacOS/releases/tag/v1.6)

* 新增 Alfred 快捷发送消息 & 打开聊天窗口

### [v1.5.1 (2018-03-03)](https://github.com/TKkk-iOSer/WeChatPlugin-MacOS/releases/tag/v1.5.1)

* 新增语音远程控制 mac
* 修复快捷回复后消息未读数未更新的问题
* 优化防撤回提醒 (显示撤回人昵称 & 消息类型)

### [v1.5.0 (2018-02-24)](https://github.com/TKkk-iOSer/WeChatPlugin-MacOS/releases/tag/v1.5.0)

* 优化防撤回提醒
* 新增自动登录开关
* 新增小助手检测更新
* 新增通知中心快捷回复
* 新增表情包复制 & 存储
* 自动回复 & 远程控制设置存储到本地

### [v1.4.0 (2017-10-11)](https://github.com/TKkk-iOSer/WeChatPlugin-MacOS/releases/tag/v1.4.0)

* 新增微信窗口置顶
* 新增最近联系人多选删除
* 新增远程控制信息回调
* 新增手机端获取指令信息

### [v1.3.0 (2017-09-17)](https://github.com/TKkk-iOSer/WeChatPlugin-MacOS/releases/tag/v1.3.0)

* 新增最近联系人置底功能
* 新增免认证登录

### [v1.2.0 (2017-09-11)](https://github.com/TKkk-iOSer/WeChatPlugin-MacOS/releases/tag/v1.2.0)

* 自动回复新增 正则匹配 & 私聊开关
* 修复聊天记录消失 & `~/Documents` 生成MMappedKV、JietuSDKStat.plist 文件


### [v1.1.0 (2017-08-23)](https://github.com/TKkk-iOSer/WeChatPlugin-MacOS/releases/tag/v1.1.0)

* 重构 自动回复，实现多回复
* 优化 代码结构

### [v1.0.1 (2017-08-18)](https://github.com/TKkk-iOSer/WeChatPlugin-MacOS/releases/tag/v1.0.1)

* 修复 部分防撤回提示乱码的bug
* 新增 Install.sh  & Uninstall.sh   

### [v1.0.0 (2017-08-09)](https://github.com/TKkk-iOSer/WeChatPlugin-MacOS/releases/tag/v1.0.0)

* 新增 远程控制
* 新增 微信多开
* 优化 消息防撤回
* 优化 自动回复

