//
//  TKRemoteControlWindowController.h
//  WeChatPlugin
//
//  Created by TK on 2017/8/8.
//  Copyright © 2017年 tk. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface TKRemoteControlWindowController : NSWindowController

@end
