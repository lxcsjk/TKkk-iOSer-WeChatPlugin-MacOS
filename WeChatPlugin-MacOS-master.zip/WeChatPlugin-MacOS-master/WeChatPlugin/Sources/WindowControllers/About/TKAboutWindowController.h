//
//  TKAboutWindowController.h
//  WeChatPlugin
//
//  Created by TK on 2018/5/4.
//  Copyright © 2018年 tk. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface TKAboutWindowController : NSWindowController

@end
