//
//  NSMenu+Action.h
//  WeChatPlugin
//
//  Created by TK on 2018/4/15.
//  Copyright © 2018年 tk. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSMenu (Action)

- (void)addItems:(NSArray *)subItems;

@end
