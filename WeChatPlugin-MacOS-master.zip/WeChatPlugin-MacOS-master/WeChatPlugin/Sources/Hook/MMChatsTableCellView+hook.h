//
//  MMChatsTableCellView+hook.h
//  WeChatPlugin
//
//  Created by TK on 2017/9/15.
//  Copyright © 2017年 tk. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSObject (MMChatsTableCellViewHook)

+ (void)hookMMChatsTableCellView;

@end
