//
//  MMStickerMessageCellView+hook.m
//  WeChatPlugin
//
//  Created by TK on 2018/2/23.
//  Copyright © 2018年 tk. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface NSObject (MMStickerMessageCellView)

+ (void)hookMMStickerMessageCellView;

@end
